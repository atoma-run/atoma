Museum capsule v1
